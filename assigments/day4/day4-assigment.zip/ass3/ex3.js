const express = require("express");
require("dotenv").config();
require("./api/data/dbconnection.js").open();
const app = express();

app.use()